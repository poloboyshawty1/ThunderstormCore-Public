<?php

/*
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 * ▀█▀ █░░ █░█ █▄░█ █▀▄ █▀▀ █▀▀▄ ▄▀▀ ▀█▀ ▄▀▄ █▀▀▄ █▄░▄█ 
 * ░█░ █▀▄ █░█ █░▀█ █░█ █▀▀ █▐█▀ ░▀▄ ░█░ █░█ █▐█▀ █░█░█ 
 * ░▀░ ▀░▀ ░▀░ ▀░░▀ ▀▀░ ▀▀▀ ▀░▀▀ ▀▀░ ░▀░ ░▀░ ▀░▀▀ ▀░░░▀ 
 *
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 */

namespace pocketmine\command\defaults;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Utils;

class StatusCommand extends VanillaCommand {

	/**
	 * StatusCommand constructor.
	 *
	 * @param $name
	 */
	public function __construct($name){
		parent::__construct(
			$name,
			"%pocketmine.command.status.description",
			"%pocketmine.command.status.usage"
		);
		$this->setPermission("pocketmine.command.status");
	}

	/**
	 * @param CommandSender $sender
	 * @param string        $currentAlias
	 * @param array         $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, $currentAlias, array $args){
		if(!$this->testPermission($sender)){
			return true;
		}

		$rUsage = Utils::getRealMemoryUsage();
		$mUsage = Utils::getMemoryUsage(true);

		$server = $sender->getServer();
		$sender->sendMessage('§f• Информация о работе Thunderstorm Core •§r');

		$time = (int) (microtime(true) - \pocketmine\START_TIME);

		$seconds = $time % 60;
		$minutes = null;
		$hours = null;
		$days = null;

		if($time >= 60){
			$minutes = floor(($time % 3600) / 60);
			if($time >= 3600){
				$hours = floor(($time % (3600 * 24)) / 3600);
				if($time >= 3600 * 24){
					$days = floor($time / (3600 * 24));
				}
			}
		}

		$uptime = ($minutes !== null ?
				($hours !== null ?
					($days !== null ?
						"$days дней "
					: "") . "$hours часов(-а) "
					: "") . "$minutes минут(-ы) "
			: "") . "$seconds секунд(-ы)";

		$sender->sendMessage("§r§cАптайм: §f". $uptime);

		$tpsColor = TextFormat::WHITE;
		if($server->getTicksPerSecond() < 17){
			$tpsColor = TextFormat::GOLD;
		}elseif($server->getTicksPerSecond() < 12){
			$tpsColor = TextFormat::RED;
		}

		$sender->sendMessage('§c' . '%pocketmine.command.status.CurrentTPS ' . '§r§f' . $server->getTicksPerSecond() . ' (' . $server->getTickUsage() . '%)');
		$sender->sendMessage('§c' . '%pocketmine.command.status.AverageTPS ' . '§r§f' . $server->getTicksPerSecondAverage() . ' (' . $server->getTickUsageAverage() . '%)');
 
		$onlineCount = 0;
		foreach($sender->getServer()->getOnlinePlayers() as $player){
			if($player->isOnline() and (!($sender instanceof Player) or $sender->canSee($player))){
				++$onlineCount;
			}
		}

		$sender->sendMessage("§c". "%pocketmine.command.status.player" . "§r§f" . " " . $onlineCount . "/" . $sender->getServer()->getMaxPlayers());
		$sender->sendMessage("§c".  TextFormat::WHITE . "§cКоличество ядер: " . "§r§f" . Utils::getCoreCount(true));
		$sender->sendMessage("§c". "%pocketmine.command.status.Networkupload " . "§r§f" . \round($server->getNetwork()->getUpload() / 1024, 2) . " kB/s");
		$sender->sendMessage("§c". "%pocketmine.command.status.Networkdownload " . "§r§f" . \round($server->getNetwork()->getDownload() / 1024, 2) . " kB/s");
		$sender->sendMessage("§cПлагинов включено: " . TextFormat::WHITE . count($server->getPluginManager()->getPlugins()));
		$sender->sendMessage("§c". "%pocketmine.command.status.Threadcount " . "§r§f" . Utils::getThreadCount());
		$sender->sendMessage("§c". "%pocketmine.command.status.Mainmemory " . "§r§f" . number_format(round(($mUsage[0] / 1024) / 1024, 2), 2) . " MB.");
		$sender->sendMessage("§c". "%pocketmine.command.status.Totalmemory " . "§r§f" . number_format(round(($mUsage[1] / 1024) / 1024, 2), 2) . " MB.");
		$sender->sendMessage("§c". "%pocketmine.command.status.Totalvirtualmemory " . "§r§f" . number_format(round(($mUsage[2] / 1024) / 1024, 2), 2) . " MB.");
		$sender->sendMessage("§c". "%pocketmine.command.status.Heapmemory " . "§r§f" . number_format(round(($rUsage[0] / 1024) / 1024, 2), 2) . " MB.");

		if($server->getProperty("memory.global-limit") > 0){
			$sender->sendMessage("§c". "%pocketmine.command.status.Maxmemorymanager " . "§l§f" . number_format(round($server->getProperty("memory.global-limit"), 2), 2) . " MB.");
		}

		foreach($server->getLevels() as $level){
			$levelName = $level->getFolderName() !== $level->getName() ? " (" . $level->getName() . ")" : "";
			$timeColor = $level->getTickRateTime() > 40 ? TextFormat::RED : TextFormat::YELLOW;
			$sender->sendMessage("§c". "Мир \"{$level->getFolderName()}\"$levelName: " .
			"§r§f" . number_format(count($level->getChunks())) . "§r§f" . " %pocketmine.command.status.chunks " .
			"§r§f" . number_format(count($level->getEntities())) . "§r§f" . " %pocketmine.command.status.entities " .
			"§r§f" . number_format(count($level->getTiles())) . "§r§f" . " %pocketmine.command.status.tiles " .
				"%pocketmine.command.status.Time " . round($level->getTickRateTime(), 2) . "мс"
			);
		}

		return true;
	}
}
