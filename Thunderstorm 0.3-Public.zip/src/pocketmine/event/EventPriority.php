<?php

/*
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 * ▀█▀ █░░ █░█ █▄░█ █▀▄ █▀▀ █▀▀▄ ▄▀▀ ▀█▀ ▄▀▄ █▀▀▄ █▄░▄█ 
 * ░█░ █▀▄ █░█ █░▀█ █░█ █▀▀ █▐█▀ ░▀▄ ░█░ █░█ █▐█▀ █░█░█ 
 * ░▀░ ▀░▀ ░▀░ ▀░░▀ ▀▀░ ▀▀▀ ▀░▀▀ ▀▀░ ░▀░ ░▀░ ▀░▀▀ ▀░░░▀ 
 *
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 */
 
namespace pocketmine\event;


/**
 * Список приоритетов событий
 *
 * События будут вызываться в таком порядке:
 * САМЫЙ НИЗКИЙ -> НИЗКИЙ -> НОРМАЛЬНЫЙ -> ВЫСОКИЙ -> ВЫСОКИЙ -> МОНИТОР
 *
 * События МОНИТОР не должны изменять результат или содержание события
 */
abstract class EventPriority {
	public const ALL = [
		self::LOWEST,
		self::LOW,
		self::NORMAL,
		self::HIGH,
		self::HIGHEST,
		self::MONITOR
	];

    /**
     * Вызов события имеет очень малое значение и должен выполняться первым, чтобы разрешить
     * другие плагины для дальнейшей настройки результата
     */
	const LOWEST = 5;
    /**
     * Вызов события не имеет большого значения
     */
	const LOW = 4;
    /**
     * Вызов события не является ни важным, ни неважным, и может выполняться в обычном режиме.
     * Это приоритет по умолчанию.
     */
	const NORMAL = 3;
    /**
     * Вызов события имеет большое значение
     */
	const HIGH = 2;
    /**
     * Объявление о мероприятии имеет решающее значение и должно иметь последнее слово в том, что происходит
     * на мероприятие
     */
	const HIGHEST = 1;
    /**
     * Событие прослушивается исключительно для наблюдения за исходом события.
     *
     * Не следует вносить изменения в событие с этим приоритетом.
     */
	const MONITOR = 0;

	/**
	 * @param string $name
	 *
	 * @return int
	 *
	 * @throws \InvalidArgumentException
	 */
	public static function fromString(string $name) : int{
		$name = strtoupper($name);
		$const = self::class . "::" . $name;
		if($name !== "ALL" and \defined($const)){
			return \constant($const);
		}

		throw new \InvalidArgumentException("Не удалось определить приоритет \"$name\"");
	}
}