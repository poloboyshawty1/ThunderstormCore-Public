<?php

/*
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 * ▀█▀ █░░ █░█ █▄░█ █▀▄ █▀▀ █▀▀▄ ▄▀▀ ▀█▀ ▄▀▄ █▀▀▄ █▄░▄█ 
 * ░█░ █▀▄ █░█ █░▀█ █░█ █▀▀ █▐█▀ ░▀▄ ░█░ █░█ █▐█▀ █░█░█ 
 * ░▀░ ▀░▀ ░▀░ ▀░░▀ ▀▀░ ▀▀▀ ▀░▀▀ ▀▀░ ░▀░ ░▀░ ▀░▀▀ ▀░░░▀ 
 *
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 */

/**
 * События, связанные с объектами, такие как появление, инвентарь, атака...
 */

namespace pocketmine\event\entity;

use pocketmine\event\Event;

abstract class EntityEvent extends Event {
	/** @var \pocketmine\entity\Entity */
	protected $entity;

	/**
	 * @return \pocketmine\entity\Entity
	 */
	public function getEntity(){
		return $this->entity;
	}
}