<?php

/*
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 * ▀█▀ █░░ █░█ █▄░█ █▀▄ █▀▀ █▀▀▄ ▄▀▀ ▀█▀ ▄▀▄ █▀▀▄ █▄░▄█ 
 * ░█░ █▀▄ █░█ █░▀█ █░█ █▀▀ █▐█▀ ░▀▄ ░█░ █░█ █▐█▀ █░█░█ 
 * ░▀░ ▀░▀ ░▀░ ▀░░▀ ▀▀░ ▀▀▀ ▀░▀▀ ▀▀░ ░▀░ ░▀░ ▀░▀▀ ▀░░░▀ 
 *
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 */

namespace pocketmine\event\entity;

use pocketmine\entity\Entity;

/**
 * Вызывается, когда объект получает урон от объекта, полученного от другого объекта, например, если его ударил снежок, брошенный игроком.
 */
class EntityDamageByChildEntityEvent extends EntityDamageByEntityEvent {
	/** @var int */
	private $childEntityEid;

	public function __construct(Entity $damager, Entity $childEntity, Entity $entity, int $cause, $damage){
		$this->childEntityEid = $childEntity->getId();
		parent::__construct($damager, $entity, $cause, $damage);
	}

    /**
     * Возвращает объект, причинивший ущерб, или ноль, если объект был убит или закрыт.
     */
	public function getChild(){
		return $this->getEntity()->getLevel()->getServer()->findEntity($this->childEntityEid);
	}
}