<?php

/*
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 * ▀█▀ █░░ █░█ █▄░█ █▀▄ █▀▀ █▀▀▄ ▄▀▀ ▀█▀ ▄▀▄ █▀▀▄ █▄░▄█ 
 * ░█░ █▀▄ █░█ █░▀█ █░█ █▀▀ █▐█▀ ░▀▄ ░█░ █░█ █▐█▀ █░█░█ 
 * ░▀░ ▀░▀ ░▀░ ▀░░▀ ▀▀░ ▀▀▀ ▀░▀▀ ▀▀░ ░▀░ ░▀░ ▀░▀▀ ▀░░░▀ 
 *
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 */

namespace pocketmine\entity;

class InstantEffect extends Effect {

}