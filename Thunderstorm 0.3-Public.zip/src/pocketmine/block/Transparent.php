<?php

/*
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 * ▀█▀ █░░ █░█ █▄░█ █▀▄ █▀▀ █▀▀▄ ▄▀▀ ▀█▀ ▄▀▄ █▀▀▄ █▄░▄█ 
 * ░█░ █▀▄ █░█ █░▀█ █░█ █▀▀ █▐█▀ ░▀▄ ░█░ █░█ █▐█▀ █░█░█ 
 * ░▀░ ▀░▀ ░▀░ ▀░░▀ ▀▀░ ▀▀▀ ▀░▀▀ ▀▀░ ░▀░ ░▀░ ▀░▀▀ ▀░░░▀ 
 *
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 */

namespace pocketmine\block;


abstract class Transparent extends Block {

	/**
	 * @return bool
	 */
	public function isTransparent(){
		return true;
	}

	public function getLightFilter() : int{
		return 0;
	}
}