<?php

/*
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 * ▀█▀ █░░ █░█ █▄░█ █▀▄ █▀▀ █▀▀▄ ▄▀▀ ▀█▀ ▄▀▄ █▀▀▄ █▄░▄█ 
 * ░█░ █▀▄ █░█ █░▀█ █░█ █▀▀ █▐█▀ ░▀▄ ░█░ █░█ █▐█▀ █░█░█ 
 * ░▀░ ▀░▀ ░▀░ ▀░░▀ ▀▀░ ▀▀▀ ▀░▀▀ ▀▀░ ░▀░ ░▀░ ▀░▀▀ ▀░░░▀ 
 *
 * @author Thunderstorm Team
 * @link http://vk.com/thunderstorm.team
 *
 *
 */

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\item\Tool;

class DoubleSlab extends Solid {

	protected $id = self::DOUBLE_SLAB;

	/**
	 * DoubleSlab constructor.
	 *
	 * @param int $meta
	 */
	public function __construct($meta = 0){
		$this->meta = $meta;
	}

	/**
	 * @return int
	 */
	public function getHardness(){
		return 2;
	}

	/**
	 * @return int
	 */
	public function getToolType(){
		return Tool::TYPE_PICKAXE;
	}

	/**
	 * @return string
	 */
	public function getName() : string{
		static $names = [
			0 => "Stone",
			1 => "Sandstone",
			2 => "Wooden",
			3 => "Cobblestone",
			4 => "Brick",
			5 => "Stone Brick",
			6 => "Quartz",
			7 => "Nether Brick",
		];
		return "Double " . $names[$this->meta & 0x07] . " Slab";
	}

	/**
	 * @param Item $item
	 *
	 * @return array
	 */
	public function getDrops(Item $item) : array{
		if($item->isPickaxe() >= 1){
			return [
				[Item::SLAB, $this->meta & 0x07, 2],
			];
		}else{
			return [];
		}
	}

}